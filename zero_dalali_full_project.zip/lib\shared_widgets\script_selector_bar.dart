import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../core/services/realtime_quote_service.dart';
import '../core/theme/trading_colors.dart';
import '../core/theme/typography.dart';
import '../data/models/models.dart';
import '../features/market/data/real_market_repository.dart';
import '../features/order_entry/presentation/order_entry_sheet.dart';
import '../features/profile_settings/data/pinned_instruments_repository.dart';

class ScriptSelectorBar extends ConsumerStatefulWidget {
  final Instrument? leftScript;
  final Instrument? rightScript;
  final ValueChanged<Instrument>? onLeftScriptChanged;
  final ValueChanged<Instrument>? onRightScriptChanged;

  const ScriptSelectorBar({
    super.key,
    this.leftScript,
    this.rightScript,
    this.onLeftScriptChanged,
    this.onRightScriptChanged,
  });

  @override
  ConsumerState<ScriptSelectorBar> createState() => _ScriptSelectorBarState();
}

class _ScriptSelectorBarState extends ConsumerState<ScriptSelectorBar> {
  void _openScriptPicker(bool isLeft) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        final colors = context.tradingColors;
        final repo = ref.read(marketRepositoryProvider);
        final allScripts = repo.cachedInstruments;
        String pickerQuery = '';

        return StatefulBuilder(
          builder: (bottomSheetContext, setModalState) {
            final filtered = pickerQuery.isEmpty
                ? allScripts
                : allScripts
                    .where((s) =>
                        s.symbol
                            .toLowerCase()
                            .contains(pickerQuery.toLowerCase()) ||
                        s.name
                            .toLowerCase()
                            .contains(pickerQuery.toLowerCase()))
                    .toList();

            return DraggableScrollableSheet(
              initialChildSize: 0.75,
              minChildSize: 0.4,
              maxChildSize: 0.95,
              expand: false,
              builder: (_, controller) {
                return Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 12, bottom: 8),
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: colors.divider,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Text(
                        isLeft
                            ? 'Select Left Quick Script'
                            : 'Select Right Quick Script',
                        style: AppTypography.h2(
                            color: colors.textPrimary,
                            weight: FontWeight.w700),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 6),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: colors.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: colors.divider),
                        ),
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: 'Search script to bind...',
                            prefixIcon: Icon(LucideIcons.search,
                                color: colors.textSecondary, size: 18),
                            border: InputBorder.none,
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 12),
                          ),
                          onChanged: (val) {
                            setModalState(() => pickerQuery = val);
                          },
                        ),
                      ),
                    ),
                    const Divider(height: 1),
                    Expanded(
                      child: ListView.separated(
                        controller: controller,
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          final script = filtered[index];
                          return ListTile(
                            title: Text(script.symbol,
                                style:
                                    AppTypography.body(weight: FontWeight.w600)),
                            subtitle: Text(
                                '${script.name} • ${script.exchange.name}',
                                style: AppTypography.caption(
                                    color: colors.textSecondary)),
                            trailing: Icon(LucideIcons.plusCircle,
                                color: colors.secondary, size: 20),
                            onTap: () {
                              final notifier =
                                  ref.read(pinnedScriptsProvider.notifier);
                              if (isLeft) {
                                notifier.setLeftScript(script);
                                widget.onLeftScriptChanged?.call(script);
                              } else {
                                notifier.setRightScript(script);
                                widget.onRightScriptChanged?.call(script);
                              }
                              Navigator.pop(context);
                            },
                          );
                        },
                      ),
                    ),
                  ],
                );
              },
            );
          },
        );
      },
    );
  }

  void _showScriptQuickActions(Instrument script, bool isLeft) {
    final colors = context.tradingColors;
    showModalBottomSheet(
      context: context,
      backgroundColor: colors.cardBackground,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetCtx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          script.symbol,
                          style: AppTypography.h2(
                              color: colors.textPrimary,
                              weight: FontWeight.w700),
                        ),
                        Text(
                          '${script.name} • ${script.exchange.name}',
                          style: AppTypography.caption(
                              color: colors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(LucideIcons.x, color: colors.textSecondary, size: 20),
                    onPressed: () => Navigator.pop(sheetCtx),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: Icon(LucideIcons.trendingUp, color: colors.primary, size: 20),
              title: Text('Trade / Place Order',
                  style: TextStyle(
                      color: colors.primary, fontWeight: FontWeight.w600)),
              onTap: () {
                Navigator.pop(sheetCtx);
                OrderEntrySheet.show(context, instrument: script);
              },
            ),
            ListTile(
              leading: Icon(LucideIcons.candlestickChart, color: colors.textPrimary, size: 20),
              title: Text('View Fullscreen Chart',
                  style: TextStyle(color: colors.textPrimary)),
              onTap: () {
                Navigator.pop(sheetCtx);
                context.push('/chart-fullscreen/${script.token}');
              },
            ),
            ListTile(
              leading: Icon(LucideIcons.info, color: colors.textPrimary, size: 20),
              title: Text('Script Details',
                  style: TextStyle(color: colors.textPrimary)),
              onTap: () {
                Navigator.pop(sheetCtx);
                context.push('/quote/${script.token}');
              },
            ),
            ListTile(
              leading: Icon(LucideIcons.arrowLeftRight, color: colors.secondary, size: 20),
              title: Text('Change Script',
                  style: TextStyle(color: colors.textPrimary)),
              onTap: () {
                Navigator.pop(sheetCtx);
                _openScriptPicker(isLeft);
              },
            ),
            ListTile(
              leading: Icon(LucideIcons.trash2, color: colors.bearish, size: 20),
              title: Text('Unpin from Bar',
                  style: TextStyle(color: colors.bearish)),
              onTap: () {
                Navigator.pop(sheetCtx);
                ref.read(pinnedScriptsProvider.notifier).clearSlot(isLeft);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.tradingColors;
    final pinned = ref.watch(pinnedScriptsProvider);
    final leftScript = widget.leftScript ?? pinned.leftScript;
    final rightScript = widget.rightScript ?? pinned.rightScript;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 6.0),
      color: colors.background,
      child: Row(
        children: [
          // Left Script Button
          Expanded(
            child: _buildScriptButton(
              script: leftScript,
              isLeft: true,
              colors: colors,
            ),
          ),
          const SizedBox(width: 8),
          // Right Script Button
          Expanded(
            child: _buildScriptButton(
              script: rightScript,
              isLeft: false,
              colors: colors,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScriptButton({
    required Instrument? script,
    required bool isLeft,
    required TradingColors colors,
  }) {
    Quote? liveQuote;
    if (script != null) {
      try {
        final ticker = ref.watch(tickerServiceProvider);
        liveQuote = ticker.getQuote(script.token);
      } catch (_) {}
    }

    return InkWell(
      onTap: () {
        if (script != null) {
          _showScriptQuickActions(script, isLeft);
        } else {
          _openScriptPicker(isLeft);
        }
      },
      onLongPress: () => _openScriptPicker(isLeft),
      borderRadius: BorderRadius.circular(6),
      child: Container(
        height: 38,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: colors.scriptBarBackground,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: script != null ? colors.primary : colors.secondary,
                shape: BoxShape.circle,
              ),
              child: Icon(
                script != null ? LucideIcons.check : LucideIcons.plus,
                size: 13,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 6),
            Flexible(
              child: script != null
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Flexible(
                          child: Text(
                            script.symbol,
                            style: AppTypography.labelSmall(
                              color: colors.textPrimary,
                              weight: FontWeight.w700,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (liveQuote != null) ...[
                          const SizedBox(width: 4),
                          Text(
                            liveQuote.ltp.toStringAsFixed(1),
                            style: AppTypography.caption(
                              color: liveQuote.changePercent >= 0
                                  ? colors.bullish
                                  : colors.bearish,
                              weight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ],
                    )
                  : Text(
                      'Press and hold to select script',
                      style: AppTypography.labelSmall(
                        color: colors.textPrimary,
                        weight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
